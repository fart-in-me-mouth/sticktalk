// Real local server. No fixture API routes, mock websocket, external service,
// visible window, hardware device, notification, or non-loopback listener.
import { chromium } from "file:///C:/Users/dwhee/.t3/worktrees/discord%20clone/t3-2479b5fd-66564cf4aed16f74/crates/web/node_modules/playwright/index.mjs";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { once } from "node:events";
import { mkdtemp, rm, writeFile, mkdir, readFile } from "node:fs/promises";
import { resolve, join, dirname, basename } from "node:path";
const target = resolve(
  process.env.CARGO_TARGET_DIR ??
    "C:/Users/dwhee/.cargo-target/sticktalk-web-live",
);
const data = await mkdtemp(join(target, "live-test-"));
const reserve = createServer();
reserve.listen(0, "127.0.0.1");
await once(reserve, "listening");
const port = reserve.address().port;
await new Promise((r) => reserve.close(r));
const origin = `http://127.0.0.1:${port}`;
const server = spawn(
  process.env.STICKTALK_SERVER_EXE ??
    join(target, "debug/sticktalk-server.exe"),
  [
    "--bind",
    `127.0.0.1:${port}`,
    "--public-url",
    origin,
    "--data-dir",
    data,
    "--web-root",
    (process.env.STICKTALK_WEB_DIST ?? join(target, "web-dist")),
    "--min-free-disk-gb",
    "0",
    "--voice-bind-ip",
    "127.0.0.1",
    "--voice-advertised-ip",
    "127.0.0.1",
  ],
  { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] },
);
const errors = [],
  violations = [],
  checks = [];
let log = "",
  browsers = [],
  pages = [];
const act = (page, action) =>
  page.evaluate(
    (action) =>
      window.dispatchEvent(
        new CustomEvent("sticktalk-live", { detail: action }),
      ),
    action,
  );
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const expect = async (page, fn, arg) =>
  page.waitForFunction(fn, arg, { timeout: 30000 });
async function register(page, user) {
  await page.goto(origin);
  if (user === "alice_web") {
    await mkdir("screenshots/live", { recursive: true });
    for (const [width, height] of [
      [1440, 900],
      [390, 844],
      [412, 915],
      [820, 1180],
    [1280, 800],
    [1920, 1080],
    ]) {
      await page.setViewportSize({ width, height });
      await page.evaluate(() => document.fonts.ready);
      await page.screenshot({
        path: `screenshots/live/login-${width}x${height}.png`,
      });
    }
    await page.setViewportSize({ width: 1440, height: 900 });
  }
  await page.waitForSelector("#auth-username");
  await page.waitForFunction(
    () => !document.querySelector("[type=submit]").disabled,
  );
  await page.locator("[data-live=register]").click();
  await page.locator("#auth-username").fill(user);
  await page.locator("#auth-password").fill("testing-password-123456");
  await page.locator("[type=submit]").click();
  await page.waitForSelector(".live-home");
  await page.waitForFunction(
    () => !document.querySelector(".connection-banner"),
  );
}
async function form(page, kind, name, extra = {}) {
  await act(page, `dialog:${kind}`);
  await page.waitForSelector('.live-modal [data-live-form]');
  if (await page.locator("#f-name").isVisible())
    await page.locator("#f-name").fill(name);
  for (const [id, value] of Object.entries(extra)) {
    const e = page.locator(`#${id}`);
    if (await e.evaluate((e) => e.tagName === "SELECT"))
      await e.selectOption(value);
    else await e.fill(value);
  }
  await page.locator("[data-live-form] [type=submit]").click();
}
async function message(page, text) {
  await page.locator("#live-input").fill(text);
  await act(page, "complete-close");
  await page.locator("#live-input").press("Enter");
  await page.waitForFunction(
    (text) =>
      [...document.querySelectorAll(".markdown")].some((e) =>
        e.textContent.includes(text.replaceAll("**", "")),
      ),
    text,
  );
}
async function capture(page, prefix) {
  await page.mouse.move(0,0);
  for (const [width,height] of [[390,844],[412,915],[820,1180],[1440,900],[1280,800],[1920,1080]]) {
    await page.setViewportSize({width,height});
    await page.evaluate(()=>document.fonts.ready);
    await page.evaluate(()=>{const list=document.querySelector("#live-messages"); if(list&&!document.querySelector(".live-modal,#live-viewer"))list.scrollTop=list.scrollHeight;});
    await wait(80);
    await page.evaluate(()=>{const list=document.querySelector('#live-messages');if(list&&!document.querySelector('.live-modal,#live-viewer'))list.scrollTop=list.scrollHeight;});
    await page.screenshot({path:`screenshots/live/${prefix}-${width}x${height}.png`});
  }
  await page.setViewportSize({width:1440,height:900});
}
async function diagnostic(page) {
  return page.evaluate(async () => {
    const m = await import("/public/media.js");
    return m.diagnostics();
  });
}
try {
  await new Promise((done, fail) => {
    const timer = setTimeout(() => fail(Error(`server timeout ${log}`)), 30000);
    const collect = (c) => {
      log = (log + c).slice(-20000);
      if (log.includes("StickTalk listening")) {
        clearTimeout(timer);
        done();
      }
    };
    server.stdout.on("data", collect);
    server.stderr.on("data", collect);
    server.once("error", fail);
    server.once("exit", (code) => fail(Error(`server exited ${code}: ${log}`)));
  });
  const launch = () =>
    chromium.launch({
      headless: true,
      args: [
        "--use-fake-device-for-media-stream",
        "--use-fake-ui-for-media-stream",
        "--allow-loopback-in-peer-connection",
        "--disable-features=WebRtcHideLocalIpsWithMdns",
        "--mute-audio",
        "--disable-notifications",
      ],
    });
  browsers = [await launch(), await launch()];
  const contexts = await Promise.all(
    browsers.map((b) =>
      b.newContext({
        viewport: { width: 1440, height: 900 },
        permissions: ["microphone", "camera"],
      }),
    ),
  );
  const [alice, bob] = (pages = await Promise.all(
    contexts.map((c) => c.newPage()),
  ));
  for (const page of [alice, bob]) {
    page.on("pageerror", (e) => errors.push(e.stack ?? String(e)));
    await page.addInitScript(() => {
      document.addEventListener("securitypolicyviolation", (e) => {
        (window.__violations ??= []).push({
          directive: e.effectiveDirective,
          blocked: e.blockedURI,
        });
      });
    });
  }
  await register(alice, "alice_web");
  await register(bob, "bob_web");
  checks.push("register + cookie websocket Ready");
  const cookie = await contexts[0].cookies();
  assert(cookie.find((c) => c.name === "__Host-sticktalk_session")?.httpOnly);
  assert(cookie.find((c) => c.name === "__Host-sticktalk_session")?.secure);
  await form(alice, "friend", "bob_web");
  await bob.locator('[data-live^="friend:accept,"]').click();
  await alice.waitForSelector('[data-live^="friend:dm,"]');
  checks.push("friend request + accept via WS");
  await alice.locator('[data-live^="friend:dm,"]').click();
  await alice.waitForSelector("#live-input");
  await message(alice, "Hello **Bob**");
  const dm = await alice.locator("#live-messages").getAttribute("data-channel");
  await act(bob, `channel:${dm}`);
  await bob.waitForSelector(".markdown strong, .markdown span");
  await expect(bob, () =>
    document.querySelector(".markdown").textContent.includes("Hello Bob"),
  );
  checks.push("DM + markdown + cross-browser delivery");
  await form(alice, "create", "Browser Lab");
  await alice.waitForFunction(() => !document.querySelector(".live-modal"));
  const guild = await alice
    .locator('.server-rail [data-live^="guild:"]')
    .getAttribute("data-live");
  assert(guild);
  await form(alice,'create','Weekend Games');
  await alice.waitForFunction(()=>!document.querySelector('.live-modal'));
  await form(alice,'create','Release Engineering');
  await alice.waitForFunction(()=>!document.querySelector('.live-modal'));
  await act(alice,guild);
  await alice.waitForSelector('#live-input');
  await form(alice, "invite", "");
  await alice.waitForSelector(".live-modal code");
  const invite = await alice.locator(".live-modal code").first().textContent();
  await act(alice, "close");
  await form(bob, "join", invite);
  await bob.waitForFunction(() => !document.querySelector(".live-modal"));
  checks.push("server create + invite + join");
  const screenshots = [];
  await act(bob, guild);
  await alice.setViewportSize({ width: 1440, height: 900 });
  await form(alice, "channel", "Browser Voice", { "f-extra": "voice" });
  await alice.waitForFunction(() => !document.querySelector(".live-modal"));
  await alice.waitForSelector(
    '[data-live^="voice:"]:has-text("Browser Voice")',
  );
  const voice = await alice
    .locator('[data-live^="voice:"]:has-text("Browser Voice")')
    .getAttribute("data-live");
  await act(alice, voice);
  await act(bob, voice);
  // Browser metrics, not signaling acknowledgements, prove real SFU media flow.
  let proof;
  for (let i = 0; i < 90; i++) {
    await wait(500);
    const result = await Promise.all([diagnostic(alice), diagnostic(bob)]);
    if (
      result.every(
        (d) =>
          d.state === "connected" &&
          d.stats.some(
            (r) =>
              r.type === "inbound-rtp" &&
              r.kind === "audio" &&
              r.bytesReceived > 0,
          ),
      )
    ) {
      proof = result;
      break;
    }
  }
  if (!proof)
    await writeFile(
      "screenshots/live/media-failure.json",
      JSON.stringify(
        await Promise.all([diagnostic(alice), diagnostic(bob)]),
        null,
        2,
      ),
    );
  assert(
    proof,
    `two-browser audio failed: ${JSON.stringify(await Promise.all([diagnostic(alice), diagnostic(bob)]))}; errors=${errors}; server=${log}`,
  );
  checks.push("two independent Chromium processes exchange audio through SFU");
  await act(alice, "media:camera");
  await act(bob, "media:camera");
  let video;
  for (let i = 0; i < 90; i++) {
    await wait(500);
    const result = await Promise.all([diagnostic(alice), diagnostic(bob)]);
    if (
      result.every(
        (d) =>
          d.stats.some(
            (r) =>
              r.type === "inbound-rtp" &&
              r.kind === "video" &&
              r.framesDecoded >= 10,
          ) &&
          d.tracks.some(
            (t) =>
              t.kind === "camera" &&
              !t.own &&
              t.videoWidth > 0 &&
              t.readyState >= 2,
          ),
      )
    ) {
      video = result;
      break;
    }
  }
  assert(
    video,
    `two-browser video failed: ${JSON.stringify(await Promise.all([diagnostic(alice), diagnostic(bob)]))}; errors=${errors}; server=${log}`,
  );
  checks.push(
    "two independent Chromium processes decode remote H.264 camera frames",
  );
  assert.equal(await alice.locator('.live-error').count(),0,'no stale typing/error toast in call');
  await writeFile(
    "screenshots/live/voice-stats.json",
    JSON.stringify(
      video.map((d) => ({
        state: d.state,
        publications: d.publications,
        subscriptions: d.subscriptions,
        tracks: d.tracks,
        stats: d.stats.filter((r) =>
          ["inbound-rtp", "outbound-rtp", "codec"].includes(r.type),
        ),
      })),
      null,
      2,
    ),
  );
  for (const [width, height] of [
    [1440, 900],
    [390, 844],
    [412, 915],
    [820, 1180],
    [1280, 800],
    [1920, 1080],
  ]) {
    await alice.setViewportSize({ width, height });
    await wait(100);
    const path = `screenshots/live/voice-${width}x${height}.png`;
    const tiles=await alice.locator('.participant-tile:not([hidden])').evaluateAll(nodes=>nodes.map(n=>({
      rect:n.getBoundingClientRect().toJSON(), kind:n.dataset.kind,
      fit:n.querySelector('video')&&getComputedStyle(n.querySelector('video')).objectFit,
    })));
    for(const t of tiles) {
      assert(Math.abs(t.rect.width/t.rect.height-16/9)<.02);
      if(t.kind==='camera')assert.equal(t.fit,'cover');
      if(width<768)assert(t.rect.bottom<height-60,'two tiles fit above bottom controls');
    }
    assert.equal(await alice.locator('.call-heading').count(),0);
    await alice.screenshot({ path });
    screenshots.push(path);
  }
  await act(alice, "media:mute");
  await act(alice, "media:deafen");
  await act(alice, "media:leave");
  await act(bob, "media:leave");
  for (const page of [alice, bob]) {
    await page.waitForFunction(async () => {
      const d = await (await import("/public/media.js")).diagnostics();
      return (
        !d.joined &&
        d.publications === 0 &&
        d.subscriptions === 0 &&
        d.tracks.length === 0
      );
    });
  }
  checks.push(
    "mute + deafen + leave; all publications/subscriptions/tracks released",
  );
  for (const page of [alice, bob])
    violations.push(...(await page.evaluate(() => window.__violations ?? [])));
  assert.deepEqual(errors, []);
  assert.deepEqual(violations, []);
  const report = {
    bundleRevision: JSON.parse(
      await readFile(join(process.env.STICKTALK_WEB_DIST ?? join(target, "web-dist"), "sizes.json"), "utf8"),
    ).revision,
    fastQa: !!process.env.STICKTALK_FAST_QA,
    realServer: true,
    headless: true,
    loopback: true,
    checks,
    screenshots,
    errors,
    violations,
    media: video.map((d) => ({
      state: d.state,
      inbound: d.stats
        .filter((r) => r.type === "inbound-rtp")
        .map(({ kind, bytesReceived, framesDecoded, packetsReceived }) => ({
          kind,
          bytesReceived,
          framesDecoded,
          packetsReceived,
        })),
    })),
  };
  await writeFile(
    "screenshots/live/results.json",
    JSON.stringify(report, null, 2),
  );
  await rm("screenshots/live-failure.json", { force: true });
  await rm("screenshots/live/media-failure.json", { force: true });
  console.log(JSON.stringify(report));
} catch (error) {
  await writeFile(
    "screenshots/live-failure.json",
    JSON.stringify(
      {
        error: String(error),
        errors,
        log,
        checks,
        pages: await Promise.all(
          pages.map((p) =>
            p
              .locator("body")
              .innerText()
              .catch(() => ""),
          ),
        ),
      },
      null,
      2,
    ),
  );
  throw error;
} finally {
  for (const b of browsers) await b.close();
  if (server.pid && server.exitCode === null) {
    const exit = once(server, "exit");
    server.kill();
    await exit;
  }
  assert.equal(dirname(resolve(data)), target);
  assert(basename(data).startsWith("live-test-"));
  await rm(data, { recursive: true, force: true });
}
